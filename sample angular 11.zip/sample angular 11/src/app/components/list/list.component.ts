import { Component, OnInit } from '@angular/core';
import {AjaxService} from './../../services/ajax.service';
@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  public model: any;
  constructor(private ajax: AjaxService) { 
    this.model = {};
    this.model.users = [];
  }

  ngOnInit(): void {
    this.ajax.get('https://reqres.in/api/users?page=2').then((data)=>{
      console.log(data);
      this.model.users = data.data;
    }).catch((error)=>{

    }).finally(()=>{

    });
  }

}
